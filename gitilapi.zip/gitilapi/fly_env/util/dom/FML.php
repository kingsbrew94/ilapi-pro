<?php namespace FLY\DOM;

/**
 * @author K.B Brew <flyartisan@gmail.com>
 * @package process
 */

interface FML {
    public function render(): Build;
}