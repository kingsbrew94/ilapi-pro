<div class="technology{# $technologyType #}">
    <div class="container">
        {:children}
    </div>
    <div class="clearfix"></div>
</div>