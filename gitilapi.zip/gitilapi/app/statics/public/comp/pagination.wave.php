<div style="margin:0 auto">
    <ol class="pagination">
        <li class="page-item"><span class="page-link" id="prev-pag">« Prev </span></li>
        {:children}
        <li class="page-item"><span class="page-link" id="next-pag"> Next »</span></li>
    </ol>
</div>