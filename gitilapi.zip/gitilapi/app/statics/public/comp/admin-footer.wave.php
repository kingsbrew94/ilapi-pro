<footer class="footer text-center"> <p class="copy_text"> &copy; Rasarp Multimedia Inc and FLY Corporation & Powered by FLY-ARTISAN.v2.0&trade; - @thisYear()</p> </footer>
