<div class="col-md-9 technology-left">
    {:children}
</div>
