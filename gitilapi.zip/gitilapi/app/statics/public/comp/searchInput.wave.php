@if isset({:val.model}[0]) && !is_empty({:val.model}):
    <input type="text" name="search" id="search" value="" style="display:inline; margin-bottom:.5em;" class="form-control form-control-line col-md-12" placeholder="Search" />
@endif
