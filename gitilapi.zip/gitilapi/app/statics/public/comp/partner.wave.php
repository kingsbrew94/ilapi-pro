<p>
    <a  href={:str.webLink} target="_blank">
        <img src="{:val.imgLink}" class="img-responsive rounded" alt="{:val.imgName}"/>
    </a>
</p>
