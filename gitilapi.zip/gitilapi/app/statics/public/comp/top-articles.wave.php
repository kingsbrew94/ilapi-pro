<div class="blog-grids">
    <div class="blog-grid-left">
        <a href={:str.topLinks}>
            <img src={:str.topStoriesImageLink} class="img-responsive" style="height:65px" alt=""/>
        </a>
    </div>
    <div class="blog-grid-right">
        <a href={:str.topLinks}>
            {:children}
        </a>
    </div>
    <div class="clearfix"> </div>
</div>
