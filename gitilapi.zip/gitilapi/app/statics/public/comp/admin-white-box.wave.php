<div class="row">
    <div class="col-md-12">
        <div class="white-box">
            {:children}
        </div>
    </div>
</div>