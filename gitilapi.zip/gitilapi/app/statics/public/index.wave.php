<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xlmns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="keywords" content="Research and Advocacy, Programs, Projects, Events, Research Centres, Publications, Blog , Support " />
    <title>{# $app_name #}</title>
    <wv-comp.app-styles />
</head>
<body class="{# $bodyClass #}">
    {:children }  
    <wv-comp.app-scripts /> 
</body>
</html>